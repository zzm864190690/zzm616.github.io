---
title: Welcome to Solana
teaser: These sample posts are provided as a template for creating your own content.
category: intro
tags: [markdown, workflow, foss]
reddit_post: 'https://www.reddit.com/r/Jekyll/comments/6258ln/welcome_to_solana/'
featured_comments:
  - url: 'https://www.reddit.com/r/Jekyll/comments/6258ln/welcome_to_solana/dfkw5k2/'
---

GitHub Pages uses a Markdown engine called <dfn>kramdown</dfn> for formatting text posts. kramdown is a superset of Markdown, meaning:

1. anything that’s valid Markdown is also valid kramdown, and
2. it provides and strictly specifies a number of features that are not available in Markdown.[^1] 

Consult the official [kramdown syntax reference][kds] for an exhaustive list of features and how to use them.

---

[^1]:
    Such as footnotes.

[kd]: http://kramdown.gettalong.org/
[rd]: https://github.com/davidfstr/rdiscount
[rc]: https://github.com/vmg/redcarpet
[kds]: https://kramdown.gettalong.org/syntax.html
